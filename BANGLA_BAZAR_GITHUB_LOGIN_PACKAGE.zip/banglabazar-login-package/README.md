# BANGLA BAZAR — GitHub Login Update Package

এই package-এ BANGLA BAZAR-এর login/account UI এবং authentication integration-এর জন্য গুরুত্বপূর্ণ ফাইলগুলো একসাথে রাখা হয়েছে।

## গুরুত্বপূর্ণ সতর্কতা

এটি পুরো BANGLA BAZAR website project নয়। আপনার আসল source code এই session-এ পাওয়া যায়নি। তাই এই package-এর code আপনার existing project-এ merge করতে হবে। Backend-এর প্রকৃত `auth.me`, login, logout এবং OAuth callback route-এর নাম source project অনুযায়ী মিলিয়ে নিতে হবে।

## ফাইলগুলোর গুরুত্ব

| ফাইল | GitHub project-এ ব্যবহার |
|---|---|
| `BANGLA_BAZAR_MobileLogin.tsx` | Mobile/WebAPK login screen component |
| `BANGLA_BAZAR_MobileLogin.css` | Login screen-এর responsive design |
| `BANGLA_BAZAR_MobileLogin_Usage.md` | বর্তমান OAuth/backend-এর সঙ্গে component যুক্ত করার নির্দেশনা |
| `BANGLA_BAZAR_account_panel_fix.md` | Account panel-এ Gmail, নাম, profile picture, logout ও session refresh-এর implementation guide |

`BANGLA_BAZAR_initial_audit.md` আলাদা audit report হিসেবে রাখা যেতে পারে; production code হিসেবে GitHub-এ দেওয়া বাধ্যতামূলক নয়।

## কীভাবে ব্যবহার করবেন

1. ZIP extract করুন।
2. `BANGLA_BAZAR_MobileLogin.tsx` এবং `.css` আপনার frontend-এর login component directory-তে রাখুন।
3. `BANGLA_BAZAR_account_panel_fix.md` অনুসরণ করে existing Account panel-এর hard-coded `Login / Create Account` block পরিবর্তন করুন।
4. `auth.me` endpoint-এর প্রকৃত response field মিলিয়ে নিন: `name`, `email`, `avatarUrl`/`photoUrl`।
5. OAuth callback ও session cookie backend-এ ঠিক আছে কি না যাচাই করুন।
6. `npm install` এবং `npm run build` চালান।
7. Google login, refresh, WebAPK reopen এবং logout end-to-end test করুন।

## GitHub-এ দেওয়ার আগে বাদ রাখবেন

- `.env` এবং আসল secret
- Gmail password বা OTP
- Payment credentials
- Private API keys
- `node_modules/`
- Build output, যদি repository-র নিয়মে প্রয়োজন না থাকে

## বাস্তব login কাজ করার শর্ত

শুধু frontend files যোগ করলে Gmail দেখাবে না যদি backend `auth.me` user ফেরত না দেয়। OAuth callback-এ signed session cookie তৈরি হতে হবে এবং frontend request-এ cookie পাঠাতে হবে।

কোনো feature পরীক্ষা না করে “working” বলা যাবে না।
