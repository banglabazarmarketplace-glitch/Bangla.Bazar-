# BANGLA BAZAR — Account Panel Login UI Fix

এই পরিবর্তনগুলো বর্তমান Manus OAuth + `auth.me` flow-এর জন্য। Firebase code থাকলে এই implementation ব্যবহার করবেন না; তখন Firebase-এর `onAuthStateChanged` দিয়ে একই user object পূরণ করতে হবে।

## 1. একটি reusable auth hook তৈরি করুন

`client/src/hooks/useCurrentUser.ts` ফাইল তৈরি করুন। `un` আপনার project-এর বিদ্যমান tRPC/API client হলে সেটি ব্যবহার করুন।

```tsx
import { useCallback, useMemo } from "react";
import { api } from "@/lib/api"; // আপনার project-এর বিদ্যমান API client নাম অনুযায়ী পরিবর্তন করুন

export function useCurrentUser() {
  const utils = api.useUtils();
  const me = api.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: true,
    staleTime: 0,
  });

  const logoutMutation = api.auth.logout.useMutation({
    onSuccess: async () => {
      await utils.auth.me.cancel();
      utils.auth.me.setData(undefined, null);
      await utils.auth.me.invalidate();
    },
  });

  const logout = useCallback(async () => {
    await logoutMutation.mutateAsync();
  }, [logoutMutation]);

  return useMemo(() => {
    const user = me.data ?? null;

    return {
      user,
      loading: me.isLoading || logoutMutation.isPending,
      error: me.error ?? logoutMutation.error ?? null,
      isAuthenticated: Boolean(user),
      refreshUser: () => me.refetch(),
      logout,
    };
  }, [me.data, me.isLoading, me.error, logoutMutation.isPending,
      logoutMutation.error, logout, me.refetch]);
}
```

> যদি আপনার existing code-এ `un.auth.me.useQuery` থাকে, `api`-এর বদলে `un` ব্যবহার করুন। নতুন client বানাবেন না।

## 2. User data-এর জন্য নিরাপদ display helper যোগ করুন

কোন field name backend-এ ব্যবহৃত হয়েছে তা source schema অনুযায়ী মিলিয়ে নিন। সাধারণত `name`, `email`, `avatarUrl` বা `photoUrl` থাকে।

```tsx
export function getUserDisplayData(user: any) {
  return {
    name: user?.name || user?.displayName || "ব্যবহারকারী",
    email: user?.email || "",
    avatarUrl: user?.avatarUrl || user?.photoUrl || user?.picture || "",
  };
}
```

Backend-এর user schema-তে Gmail address field-এর নাম `email` এবং profile image field-এর নাম `avatarUrl`/`photoUrl`—এটি নিশ্চিত করুন। অজানা field-এর উপর নির্ভর করে UI বানাবেন না।

## 3. `Home.tsx`-এর Account panel পরিবর্তন করুন

`Home.tsx`-এ hook import করুন:

```tsx
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { getUserDisplayData } from "@/lib/userDisplay";
```

Home component-এর শুরুতে যোগ করুন:

```tsx
const {
  user,
  loading: authLoading,
  isAuthenticated,
  logout,
} = useCurrentUser();

const accountUser = getUserDisplayData(user);
```

বর্তমান hard-coded account block—যেখানে সবসময় `Login / Create Account` দেখানো হয়—তার বদলে ব্যবহার করুন:

```tsx
{H === "account" && (
  <div className="account-panel-content">
    {authLoading ? (
      <div className="account-loading" aria-live="polite">
        Account যাচাই হচ্ছে…
      </div>
    ) : isAuthenticated && user ? (
      <div className="logged-in-account">
        <div className="account-profile">
          {accountUser.avatarUrl ? (
            <img
              className="account-profile-image"
              src={accountUser.avatarUrl}
              alt={`${accountUser.name}-এর profile picture`}
              referrerPolicy="no-referrer"
              onError={(event) => {
                event.currentTarget.style.display = "none";
              }}
            />
          ) : (
            <div className="account-profile-fallback" aria-hidden="true">
              {accountUser.name.slice(0, 1).toUpperCase()}
            </div>
          )}

          <div className="account-profile-details">
            <h3>{accountUser.name}</h3>
            <p className="account-email">{accountUser.email}</p>
            <span className="account-status">Logged in</span>
          </div>
        </div>

        <nav className="account-actions" aria-label="Account options">
          <button
            type="button"
            onClick={() => {
              setAccountPanel(null);
              window.location.href = "/account";
            }}
          >
            My Account
          </button>
          <button
            type="button"
            onClick={() => {
              setAccountPanel(null);
              window.location.href = "/orders";
            }}
          >
            My Orders
          </button>
          <button
            type="button"
            className="logout-button"
            disabled={authLoading}
            onClick={async () => {
              await logout();
              setAccountPanel(null);
            }}
          >
            Logout
          </button>
        </nav>
      </div>
    ) : (
      <div className="logged-out-account">
        <div className="account-avatar" aria-hidden="true">
          <UserIcon size={30} />
        </div>
        <h3>আপনার shopping account</h3>
        <p>
          Order track, address save এবং faster checkout-এর জন্য account তৈরি করুন।
        </p>
        <button
          type="button"
          className="primary-button full-button"
          onClick={() => startManusLogin()}
        >
          Login / Create Account <ArrowRightIcon size={17} />
        </button>
        <button
          type="button"
          className="back-button"
          onClick={() => setAccountPanel(null)}
        >
          এখন Guest হিসেবে থাকুন
        </button>
      </div>
    )}
  </div>
)}
```

> এখানে `H`, `setAccountPanel`, `UserIcon`, `ArrowRightIcon`, এবং `startManusLogin`-এর নাম আপনার বর্তমান `Home.tsx`-এর বিদ্যমান নাম অনুযায়ী বসাতে হবে। বর্তমান bundle-এ panel state-এর নাম ভিন্ন হলে সেটি অপরিবর্তিত রাখুন।

## 4. Login callback-এর পরে user cache refresh করুন

`/api/oauth/callback` সফলভাবে শেষ হওয়ার পরে redirect করুন:

```ts
return Response.redirect(`${origin}/?login=success`, 303);
```

Home component-এ callback query দেখলে `auth.me` refresh করুন:

```tsx
useEffect(() => {
  const params = new URLSearchParams(window.location.search);

  if (params.get("login") === "success") {
    refreshUser().finally(() => {
      params.delete("login");
      const cleanUrl = `${window.location.pathname}${
        params.toString() ? `?${params.toString()}` : ""
      }`;
      window.history.replaceState({}, document.title, cleanUrl);
    });
  }
}, [refreshUser]);
```

Hook থেকে `refreshUser` নিন:

```tsx
const {
  user,
  loading: authLoading,
  isAuthenticated,
  refreshUser,
  logout,
} = useCurrentUser();
```

## 5. CSS যোগ করুন

```css
.account-profile {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  border-radius: 14px;
  background: #f3faf7;
}

.account-profile-image,
.account-profile-fallback {
  width: 52px;
  height: 52px;
  flex: 0 0 52px;
  border-radius: 50%;
  object-fit: cover;
}

.account-profile-fallback {
  display: grid;
  place-items: center;
  color: #fff;
  background: #006a4e;
  font-size: 22px;
  font-weight: 700;
}

.account-profile-details h3 {
  margin: 0;
  font-size: 16px;
}

.account-email {
  margin: 4px 0;
  color: #58635f;
  font-size: 13px;
  overflow-wrap: anywhere;
}

.account-status {
  color: #087443;
  font-size: 12px;
  font-weight: 600;
}

.account-actions {
  display: grid;
  gap: 8px;
  margin-top: 16px;
}

.account-actions button {
  width: 100%;
  padding: 11px 12px;
  border: 1px solid #d8e5df;
  border-radius: 9px;
  background: #fff;
  text-align: left;
  cursor: pointer;
}

.account-actions .logout-button {
  color: #b42318;
}

.account-loading {
  padding: 32px 16px;
  color: #58635f;
  text-align: center;
}
```

## 6. Backend verification বাধ্যতামূলক

UI পরিবর্তনের আগে বা সঙ্গে backend-এ পরীক্ষা করুন:

```ts
// /api/oauth/callback-এর পর server response-এ থাকতে হবে
Set-Cookie: __Host-webapp_app_session=<signed-session>;
Path=/;
HttpOnly;
Secure;
SameSite=Lax;
```

এবং browser থেকে:

```ts
fetch("/api/trpc/auth.me", {
  credentials: "include",
});
```

`auth.me`-এর response-এ কমপক্ষে এই data থাকতে হবে:

```json
{
  "id": "user-id",
  "name": "User Name",
  "email": "user@gmail.com",
  "avatarUrl": "https://..."
}
```

`auth.me` যদি `null` ফেরত দেয়, শুধু frontend পরিবর্তন করলে Gmail দেখাবে না। তখন OAuth callback, session cookie এবং server-side user lookup ঠিক করতে হবে।

## 7. Acceptance test

1. Google login শুরু করুন।
2. Google account অনুমোদন শেষ করুন।
3. BANGLA BAZAR-এ ফিরে Account panel খুলুন।
4. Profile picture, নাম ও Gmail address দেখা যাচ্ছে কি না পরীক্ষা করুন।
5. Page refresh করুন—তথ্য থাকে কি না পরীক্ষা করুন।
6. WebAPK বন্ধ করে পুনরায় খুলুন—session থাকে কি না পরীক্ষা করুন।
7. Logout চাপুন—profile সরিয়ে `Login / Create Account` ফিরে আসে কি না পরীক্ষা করুন।
8. অন্য account দিয়ে login করলে পুরনো Gmail না থেকে নতুন user-এর তথ্য আসে কি না পরীক্ষা করুন।

এই কোড source repository-তে প্রয়োগ করার আগে `auth.me` user schema এবং বিদ্যমান API client-এর প্রকৃত নাম মিলিয়ে নিতে হবে।
