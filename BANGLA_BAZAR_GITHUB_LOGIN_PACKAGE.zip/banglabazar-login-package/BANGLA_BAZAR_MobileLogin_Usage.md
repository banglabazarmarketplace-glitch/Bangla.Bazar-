# BANGLA BAZAR Mobile Login Screen — ব্যবহার

## ব্যবহার

```tsx
import BANGLABAZARMobileLogin from "./BANGLA_BAZAR_MobileLogin";

export default function LoginPage() {
  return (
    <BANGLABAZARMobileLogin
      loading={false}
      onGoogleLogin={() => {
        // বর্তমান Manus OAuth flow ব্যবহার করুন।
        // Google password বা token নিজে সংগ্রহ করবেন না।
        const callback = `${window.location.origin}/api/oauth/callback`;
        window.location.href = `/api/login?redirectUri=${encodeURIComponent(callback)}`;
      }}
      onEmailLogin={async (email, password) => {
        // আপনার backend-এর প্রকৃত login mutation এখানে ব্যবহার করুন।
        // উদাহরণ: await loginMutation.mutateAsync({ email, password });
        console.log(email, password);
      }}
      onForgotPassword={(email) => {
        window.location.href = `/forgot-password?email=${encodeURIComponent(email)}`;
      }}
      onCreateAccount={() => {
        window.location.href = "/register";
      }}
      onContinueAsGuest={() => {
        window.location.href = "/";
      }}
    />
  );
}
```

## গুরুত্বপূর্ণ

- `onGoogleLogin`-এ fake login বা Gmail password field তৈরি করবেন না; বিদ্যমান Manus OAuth callback ব্যবহার করুন।
- Email/password login backend-এ বাস্তবে না থাকলে এই অংশটি UI হিসেবে থাকবে—ভুয়া success দেখাবেন না।
- Login সফল হওয়ার পরে `/api/trpc/auth.me` বা বিদ্যমান user endpoint refetch করে Account panel-এ নাম, Gmail ও profile picture দেখান।
- Google login-এর password BANGLA BAZAR কখনো সংগ্রহ করবে না।
- এই component WebAPK/PWA-তেও responsiveভাবে কাজ করবে।
