import { FormEvent, useState } from "react";
import "./BANGLA_BAZAR_MobileLogin.css";

type MobileLoginProps = {
  onGoogleLogin: () => void;
  onEmailLogin: (email: string, password: string) => Promise<void> | void;
  onForgotPassword?: (email: string) => void;
  onCreateAccount?: () => void;
  onContinueAsGuest?: () => void;
  loading?: boolean;
  error?: string | null;
};

export default function BANGLABAZARMobileLogin({
  onGoogleLogin,
  onEmailLogin,
  onForgotPassword,
  onCreateAccount,
  onContinueAsGuest,
  loading = false,
  error = null,
}: MobileLoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLocalError(null);

    if (!email.trim() || !password) {
      setLocalError("ইমেইল এবং পাসওয়ার্ড লিখুন।");
      return;
    }

    try {
      await onEmailLogin(email.trim(), password);
    } catch {
      setLocalError("লগইন করা যায়নি। তথ্যগুলো যাচাই করে আবার চেষ্টা করুন।");
    }
  }

  const message = error || localError;

  return (
    <main className="bb-login-page">
      <section className="bb-login-card" aria-labelledby="bb-login-title">
        <div className="bb-brand-lockup" aria-label="BANGLA BAZAR">
          <div className="bb-brand-mark" aria-hidden="true">
            <span>ব</span>
          </div>
          <div>
            <div className="bb-brand-name">BANGLA BAZAR</div>
            <div className="bb-brand-tagline">বাংলার সেরা পছন্দ</div>
          </div>
        </div>

        <div className="bb-login-heading">
          <p className="bb-eyebrow">স্বাগতম</p>
          <h1 id="bb-login-title">আপনার অ্যাকাউন্টে লগইন করুন</h1>
          <p>অর্ডার ট্র্যাক করুন, পছন্দের পণ্য সংরক্ষণ করুন এবং দ্রুত checkout করুন।</p>
        </div>

        {message && (
          <div className="bb-login-alert" role="alert">
            {message}
          </div>
        )}

        <button
          type="button"
          className="bb-google-button"
          onClick={onGoogleLogin}
          disabled={loading}
        >
          <span className="bb-google-icon" aria-hidden="true">G</span>
          <span>{loading ? "অপেক্ষা করুন…" : "Google দিয়ে চালিয়ে যান"}</span>
        </button>

        <div className="bb-divider" aria-hidden="true">
          <span>অথবা</span>
        </div>

        <form className="bb-login-form" onSubmit={submit}>
          <label htmlFor="bb-email">ইমেইল ঠিকানা</label>
          <input
            id="bb-email"
            type="email"
            inputMode="email"
            autoComplete="email"
            placeholder="আপনার Gmail লিখুন"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            disabled={loading}
            required
          />

          <div className="bb-password-label-row">
            <label htmlFor="bb-password">পাসওয়ার্ড</label>
            {onForgotPassword && (
              <button
                type="button"
                className="bb-text-button"
                onClick={() => onForgotPassword(email)}
              >
                পাসওয়ার্ড ভুলে গেছেন?
              </button>
            )}
          </div>

          <div className="bb-password-wrap">
            <input
              id="bb-password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="আপনার পাসওয়ার্ড লিখুন"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              disabled={loading}
              required
            />
            <button
              type="button"
              className="bb-show-password"
              onClick={() => setShowPassword((visible) => !visible)}
              aria-label={showPassword ? "পাসওয়ার্ড লুকান" : "পাসওয়ার্ড দেখান"}
            >
              {showPassword ? "লুকান" : "দেখুন"}
            </button>
          </div>

          <button
            type="submit"
            className="bb-submit-button"
            disabled={loading}
          >
            {loading ? "লগইন হচ্ছে…" : "লগইন করুন"}
            <span aria-hidden="true">→</span>
          </button>
        </form>

        <p className="bb-signup-copy">
          নতুন গ্রাহক?{" "}
          {onCreateAccount ? (
            <button type="button" className="bb-link-button" onClick={onCreateAccount}>
              অ্যাকাউন্ট তৈরি করুন
            </button>
          ) : (
            <span>অ্যাকাউন্ট তৈরি করুন</span>
          )}
        </p>

        {onContinueAsGuest && (
          <button type="button" className="bb-guest-button" onClick={onContinueAsGuest}>
            Guest হিসেবে চালিয়ে যান
          </button>
        )}

        <p className="bb-terms">
          লগইন করলে আপনি আমাদের Terms ও Privacy Policy-তে সম্মতি দিচ্ছেন।
        </p>
      </section>
    </main>
  );
}
